export const fruitReducer = () => {
  
}