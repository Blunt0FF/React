export default function CartItem() {
  return <></>
}
