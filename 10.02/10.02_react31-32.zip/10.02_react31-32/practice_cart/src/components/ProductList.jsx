export default function ProductList() {
  return <></>
}
